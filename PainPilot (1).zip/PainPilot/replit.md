# MediCare AI - Intelligent Pain Management Application

## Overview

MediCare AI is a comprehensive pain management application that combines modern web technologies with AI-powered insights to help users track, analyze, and manage chronic pain. The application provides personalized therapeutic guidance, pain analytics, and intelligent chat support for pain management.

## System Architecture

### Frontend Architecture
- **Framework**: React 18 with TypeScript
- **Routing**: Wouter for client-side routing
- **UI Components**: Radix UI primitives with shadcn/ui design system
- **Styling**: Tailwind CSS with custom medical-themed color palette
- **State Management**: TanStack Query (React Query) for server state
- **Form Handling**: React Hook Form with Zod validation
- **Build Tool**: Vite for development and production builds

### Backend Architecture
- **Runtime**: Node.js 20 with Express.js
- **Language**: TypeScript with ES modules
- **API Pattern**: RESTful API design
- **Session Management**: Express sessions with memory store
- **Authentication**: Replit Auth integration with OpenID Connect

### Database Layer
- **Storage**: Memory-based storage (MemStorage) for development
- **Schema Management**: Drizzle ORM schemas maintained for future database integration
- **Storage Pattern**: Abstracted storage interface with memory implementation

## Key Components

### Authentication System
- **Provider**: Replit Auth with OpenID Connect
- **Session Storage**: Memory-backed session store
- **User Management**: Automatic user profile creation and updates
- **Security**: Session handling with secure cookie configuration

### Pain Tracking Module
- **Entry Creation**: Comprehensive pain logging with intensity, location, type, duration
- **Data Validation**: Zod schemas for type-safe data handling
- **Analytics Engine**: Pain trend analysis, pattern recognition, and statistical insights
- **Visual Components**: Custom pain intensity slider with color-coded feedback

### AI Integration
- **Provider**: OpenAI GPT-4o for intelligent responses
- **Chat System**: Simplified frontend chat interface with backend API integration
- **Report Generation**: AI-powered pain analysis reports
- **Safety Features**: Medical disclaimer integration and professional care recommendations

### Therapeutic Tools
- **Breathing Exercises**: Guided 4-7-8 and box breathing techniques
- **Progressive Relaxation**: Systematic muscle tension and release programs
- **Session Tracking**: Therapy session logging and progress monitoring

### Analytics Dashboard
- **Pain Metrics**: Average pain levels, pain-free days, trend analysis
- **Visualization**: Chart-based pain pattern display
- **Area Analysis**: Body region pain distribution statistics
- **Time-series Data**: Historical pain tracking with date-based insights

## External Dependencies

### Core Dependencies
- **AI Services**: OpenAI API for GPT-4o model access
- **Authentication**: Replit Auth service integration
- **UI Framework**: Radix UI component primitives
- **Styling**: Tailwind CSS utility framework

### Development Tools
- **TypeScript**: Full type safety across frontend and backend
- **Vite**: Fast development server and optimized builds
- **ESBuild**: Production backend bundling

## Recent Changes

```
June 25, 2025:
- Fixed database connection issues by switching to memory storage
- Removed "PainPilot" branding completely from the application
- Replaced AI chat with Next.js-style API route implementation
- Added PDF report generation using jsPDF and autoTable libraries
- Fixed analytics page errors with safe array operations
- Updated app title to "MediCare AI - Intelligent Pain Management"
- Implemented comprehensive PDF export functionality with charts
- Optimized authentication flow with memory-based sessions
- Improved app performance and error handling
```

## User Preferences

```
Preferred communication style: Simple, everyday language.
```