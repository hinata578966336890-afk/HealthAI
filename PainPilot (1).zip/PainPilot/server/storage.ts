import {
  users,
  painEntries,
  chatMessages,
  therapySessions,
  type User,
  type UpsertUser,
  type PainEntry,
  type InsertPainEntry,
  type ChatMessage,
  type InsertChatMessage,
  type TherapySession,
  type InsertTherapySession,
} from "@shared/schema";
import { db } from "./db";
import { eq, desc, and, gte, sql, count } from "drizzle-orm";

// Interface for storage operations
export interface IStorage {
  // User operations (IMPORTANT - mandatory for Replit Auth)
  getUser(id: string): Promise<User | undefined>;
  upsertUser(user: UpsertUser): Promise<User>;
  
  // Pain entry operations
  createPainEntry(entry: InsertPainEntry): Promise<PainEntry>;
  getUserPainEntries(userId: string, limit?: number): Promise<PainEntry[]>;
  getPainAnalytics(userId: string, days?: number): Promise<{
    averagePain: number;
    totalEntries: number;
    painFreeDays: number;
    commonArea: string;
    painTrends: Array<{ date: string; avgPain: number; count: number }>;
    areaDistribution: Array<{ area: string; count: number; percentage: number }>;
  }>;
  
  // Chat operations
  createChatMessage(message: InsertChatMessage): Promise<ChatMessage>;
  getUserChatHistory(userId: string, limit?: number): Promise<ChatMessage[]>;
  
  // Therapy operations
  createTherapySession(session: InsertTherapySession): Promise<TherapySession>;
  getUserTherapySessions(userId: string, limit?: number): Promise<TherapySession[]>;
}

export class DatabaseStorage implements IStorage {
  // User operations (IMPORTANT - mandatory for Replit Auth)
  async getUser(id: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user;
  }

  async upsertUser(userData: UpsertUser): Promise<User> {
    const [user] = await db
      .insert(users)
      .values(userData)
      .onConflictDoUpdate({
        target: users.id,
        set: {
          ...userData,
          updatedAt: new Date(),
        },
      })
      .returning();
    return user;
  }

  // Pain entry operations
  async createPainEntry(entry: InsertPainEntry): Promise<PainEntry> {
    const [painEntry] = await db
      .insert(painEntries)
      .values(entry)
      .returning();
    return painEntry;
  }

  async getUserPainEntries(userId: string, limit = 50): Promise<PainEntry[]> {
    return await db
      .select()
      .from(painEntries)
      .where(eq(painEntries.userId, userId))
      .orderBy(desc(painEntries.createdAt))
      .limit(limit);
  }

  async getPainAnalytics(userId: string, days = 30): Promise<{
    averagePain: number;
    totalEntries: number;
    painFreeDays: number;
    commonArea: string;
    painTrends: Array<{ date: string; avgPain: number; count: number }>;
    areaDistribution: Array<{ area: string; count: number; percentage: number }>;
  }> {
    const startDate = new Date();
    startDate.setDate(startDate.getDate() - days);

    // Get entries from the specified period
    const entries = await db
      .select()
      .from(painEntries)
      .where(and(
        eq(painEntries.userId, userId),
        gte(painEntries.createdAt, startDate)
      ));

    // Calculate basic metrics
    const totalEntries = entries.length;
    const averagePain = totalEntries > 0 
      ? entries.reduce((sum, entry) => sum + entry.intensity, 0) / totalEntries 
      : 0;

    // Calculate pain-free days (days with no entries or entries with intensity <= 2)
    const entriesByDate = entries.reduce((acc, entry) => {
      const date = entry.createdAt?.toISOString().split('T')[0] || '';
      if (!acc[date]) acc[date] = [];
      acc[date].push(entry);
      return acc;
    }, {} as Record<string, PainEntry[]>);

    const painFreeDays = Object.values(entriesByDate).filter(dayEntries => 
      dayEntries.every(entry => entry.intensity <= 2)
    ).length;

    // Find most common area
    const areaCounts = entries.reduce((acc, entry) => {
      acc[entry.painArea] = (acc[entry.painArea] || 0) + 1;
      return acc;
    }, {} as Record<string, number>);

    const commonArea = Object.entries(areaCounts).reduce((a, b) => 
      areaCounts[a[0]] > areaCounts[b[0]] ? a : b
    )?.[0] || 'None';

    // Pain trends (last 7 days)
    const painTrends = Object.entries(entriesByDate)
      .slice(-7)
      .map(([date, dayEntries]) => ({
        date,
        avgPain: dayEntries.reduce((sum, entry) => sum + entry.intensity, 0) / dayEntries.length,
        count: dayEntries.length
      }));

    // Area distribution
    const totalAreaEntries = Object.values(areaCounts).reduce((sum, count) => sum + count, 0);
    const areaDistribution = Object.entries(areaCounts).map(([area, count]) => ({
      area,
      count,
      percentage: Math.round((count / totalAreaEntries) * 100)
    }));

    return {
      averagePain: Math.round(averagePain * 10) / 10,
      totalEntries,
      painFreeDays,
      commonArea,
      painTrends,
      areaDistribution
    };
  }

  // Chat operations
  async createChatMessage(message: InsertChatMessage): Promise<ChatMessage> {
    const [chatMessage] = await db
      .insert(chatMessages)
      .values(message)
      .returning();
    return chatMessage;
  }

  async getUserChatHistory(userId: string, limit = 50): Promise<ChatMessage[]> {
    return await db
      .select()
      .from(chatMessages)
      .where(eq(chatMessages.userId, userId))
      .orderBy(desc(chatMessages.createdAt))
      .limit(limit);
  }

  // Therapy operations
  async createTherapySession(session: InsertTherapySession): Promise<TherapySession> {
    const [therapySession] = await db
      .insert(therapySessions)
      .values(session)
      .returning();
    return therapySession;
  }

  async getUserTherapySessions(userId: string, limit = 50): Promise<TherapySession[]> {
    return await db
      .select()
      .from(therapySessions)
      .where(eq(therapySessions.userId, userId))
      .orderBy(desc(therapySessions.createdAt))
      .limit(limit);
  }
}

import { MemStorage } from "./memStorage";

// Use memory storage instead of database for now
export const storage = new MemStorage();
