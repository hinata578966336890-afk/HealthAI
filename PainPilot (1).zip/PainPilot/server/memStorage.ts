import type {
  User,
  UpsertUser,
  PainEntry,
  InsertPainEntry,
  ChatMessage,
  InsertChatMessage,
  TherapySession,
  InsertTherapySession,
} from "@shared/schema";
import type { IStorage } from "./storage";

// In-memory storage implementation
export class MemStorage implements IStorage {
  private users = new Map<string, User>();
  private painEntries = new Map<string, PainEntry[]>();
  private chatMessages = new Map<string, ChatMessage[]>();
  private therapySessions = new Map<string, TherapySession[]>();
  private nextId = 1;

  async getUser(id: string): Promise<User | undefined> {
    return this.users.get(id);
  }

  async upsertUser(userData: UpsertUser): Promise<User> {
    const existingUser = this.users.get(userData.id);
    const user: User = {
      ...userData,
      createdAt: existingUser?.createdAt || new Date(),
      updatedAt: new Date(),
    };
    this.users.set(userData.id, user);
    return user;
  }

  async createPainEntry(entry: InsertPainEntry): Promise<PainEntry> {
    const painEntry: PainEntry = {
      id: this.nextId++,
      ...entry,
      createdAt: new Date(),
    };
    
    const userEntries = this.painEntries.get(entry.userId) || [];
    userEntries.push(painEntry);
    this.painEntries.set(entry.userId, userEntries);
    
    return painEntry;
  }

  async getUserPainEntries(userId: string, limit = 50): Promise<PainEntry[]> {
    const entries = this.painEntries.get(userId) || [];
    return entries.slice(-limit).reverse();
  }

  async getPainAnalytics(userId: string, days = 30): Promise<{
    averagePain: number;
    totalEntries: number;
    painFreeDays: number;
    commonArea: string;
    painTrends: Array<{ date: string; avgPain: number; count: number }>;
    areaDistribution: Array<{ area: string; count: number; percentage: number }>;
  }> {
    const entries = this.painEntries.get(userId) || [];
    const cutoffDate = new Date();
    cutoffDate.setDate(cutoffDate.getDate() - days);
    
    const recentEntries = entries.filter(entry => entry.createdAt >= cutoffDate);
    
    if (recentEntries.length === 0) {
      return {
        averagePain: 0,
        totalEntries: 0,
        painFreeDays: 0,
        commonArea: "None",
        painTrends: [],
        areaDistribution: [],
      };
    }

    const totalPain = recentEntries.reduce((sum, entry) => sum + entry.intensity, 0);
    const averagePain = totalPain / recentEntries.length;
    
    // Find most common area
    const areaCounts = new Map<string, number>();
    recentEntries.forEach(entry => {
      const count = areaCounts.get(entry.area) || 0;
      areaCounts.set(entry.area, count + 1);
    });
    
    const commonArea = Array.from(areaCounts.entries())
      .sort((a, b) => b[1] - a[1])[0]?.[0] || "None";

    // Calculate pain-free days (assuming pain level 0-2 is "pain-free")
    const painFreeDays = recentEntries.filter(entry => entry.intensity <= 2).length;

    // Generate trends (simplified)
    const painTrends = [];
    for (let i = 0; i < Math.min(7, days); i++) {
      const date = new Date();
      date.setDate(date.getDate() - i);
      const dayEntries = recentEntries.filter(entry => 
        entry.createdAt.toDateString() === date.toDateString()
      );
      
      if (dayEntries.length > 0) {
        const avgPain = dayEntries.reduce((sum, entry) => sum + entry.intensity, 0) / dayEntries.length;
        painTrends.push({
          date: date.toISOString().split('T')[0],
          avgPain,
          count: dayEntries.length,
        });
      }
    }

    // Area distribution
    const areaDistribution = Array.from(areaCounts.entries()).map(([area, count]) => ({
      area,
      count,
      percentage: Math.round((count / recentEntries.length) * 100),
    }));

    return {
      averagePain,
      totalEntries: recentEntries.length,
      painFreeDays,
      commonArea,
      painTrends,
      areaDistribution,
    };
  }

  async createChatMessage(message: InsertChatMessage): Promise<ChatMessage> {
    const chatMessage: ChatMessage = {
      id: this.nextId++,
      ...message,
      timestamp: new Date(),
    };
    
    const userMessages = this.chatMessages.get(message.userId) || [];
    userMessages.push(chatMessage);
    this.chatMessages.set(message.userId, userMessages);
    
    return chatMessage;
  }

  async getUserChatHistory(userId: string, limit = 50): Promise<ChatMessage[]> {
    const messages = this.chatMessages.get(userId) || [];
    return messages.slice(-limit);
  }

  async createTherapySession(session: InsertTherapySession): Promise<TherapySession> {
    const therapySession: TherapySession = {
      id: this.nextId++,
      ...session,
      timestamp: new Date(),
    };
    
    const userSessions = this.therapySessions.get(session.userId) || [];
    userSessions.push(therapySession);
    this.therapySessions.set(session.userId, userSessions);
    
    return therapySession;
  }

  async getUserTherapySessions(userId: string, limit = 50): Promise<TherapySession[]> {
    const sessions = this.therapySessions.get(userId) || [];
    return sessions.slice(-limit).reverse();
  }
}