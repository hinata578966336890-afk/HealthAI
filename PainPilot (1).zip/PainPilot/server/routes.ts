import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { setupAuth, isAuthenticated } from "./replitAuth";
import { 
  insertPainEntrySchema, 
  insertChatMessageSchema, 
  insertTherapySessionSchema 
} from "@shared/schema";
import { generatePainReport } from "./openai";
import OpenAI from "openai";

const openai = new OpenAI({
  apiKey: process.env.OPENAI_API_KEY,
});

export async function registerRoutes(app: Express): Promise<Server> {
  // Auth middleware
  await setupAuth(app);

  // Auth routes
  app.get('/api/auth/user', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const user = await storage.getUser(userId);
      res.json(user);
    } catch (error) {
      console.error("Error fetching user:", error);
      res.status(500).json({ message: "Failed to fetch user" });
    }
  });

  // Pain entry routes
  app.post('/api/pain-entries', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const validatedData = insertPainEntrySchema.parse({ ...req.body, userId });
      
      const painEntry = await storage.createPainEntry(validatedData);
      res.json(painEntry);
    } catch (error: any) {
      console.error("Error creating pain entry:", error);
      res.status(400).json({ message: error.message || "Failed to create pain entry" });
    }
  });

  app.get('/api/pain-entries', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const limit = parseInt(req.query.limit as string) || 50;
      
      const entries = await storage.getUserPainEntries(userId, limit);
      res.json(entries);
    } catch (error) {
      console.error("Error fetching pain entries:", error);
      res.status(500).json({ message: "Failed to fetch pain entries" });
    }
  });

  // Pain analytics route
  app.get('/api/pain-analytics', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const days = parseInt(req.query.days as string) || 30;
      
      const analytics = await storage.getPainAnalytics(userId, days);
      res.json(analytics);
    } catch (error) {
      console.error("Error fetching pain analytics:", error);
      res.status(500).json({ message: "Failed to fetch pain analytics" });
    }
  });

  // AI Chat routes
  app.post('/api/chat', isAuthenticated, async (req: any, res) => {
    try {
      const { message } = req.body;

      if (!message) {
        return res.status(400).json({ error: "No message provided" });
      }

      const response = await openai.chat.completions.create({
        model: "gpt-4o",
        messages: [
          {
            role: "system",
            content:
              "You are a compassionate AI assistant specializing in pain management and wellness. Provide helpful, evidence-based advice while being empathetic and supportive. Always encourage users to consult healthcare professionals for serious concerns.",
          },
          {
            role: "user",
            content: message,
          },
        ],
        max_tokens: 500,
        temperature: 0.7,
      });

      const reply = response.choices[0].message.content || "⚠️ No response generated.";
      res.json({ reply });
    } catch (error: any) {
      console.error("OpenAI error:", error);
      res.status(500).json(
        { error: "⚠️ I'm experiencing technical difficulties. Please try again." }
      );
    }
  });

  app.get('/api/chat-history', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const limit = parseInt(req.query.limit as string) || 20;
      
      const chatHistory = await storage.getUserChatHistory(userId, limit);
      res.json(chatHistory);
    } catch (error) {
      console.error("Error fetching chat history:", error);
      res.status(500).json({ message: "Failed to fetch chat history" });
    }
  });

  // Therapy session routes
  app.post('/api/therapy-sessions', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const validatedData = insertTherapySessionSchema.parse({ ...req.body, userId });
      
      const session = await storage.createTherapySession(validatedData);
      res.json(session);
    } catch (error: any) {
      console.error("Error creating therapy session:", error);
      res.status(400).json({ message: error.message || "Failed to create therapy session" });
    }
  });

  app.get('/api/therapy-sessions', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const limit = parseInt(req.query.limit as string) || 20;
      
      const sessions = await storage.getUserTherapySessions(userId, limit);
      res.json(sessions);
    } catch (error) {
      console.error("Error fetching therapy sessions:", error);
      res.status(500).json({ message: "Failed to fetch therapy sessions" });
    }
  });

  // Pain report generation
  app.get('/api/pain-report', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const days = parseInt(req.query.days as string) || 30;
      
      const analytics = await storage.getPainAnalytics(userId, days);
      const report = await generatePainReport(analytics, `${days} days`);
      
      res.json({
        ...analytics,
        aiReport: report,
        generated: new Date().toISOString()
      });
    } catch (error) {
      console.error("Error generating pain report:", error);
      res.status(500).json({ message: "Failed to generate pain report" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
