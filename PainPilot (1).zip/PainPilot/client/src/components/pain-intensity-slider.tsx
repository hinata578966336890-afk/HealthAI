import { useState } from "react";
import { Label } from "@/components/ui/label";

interface PainIntensitySliderProps {
  value: number;
  onChange: (value: number) => void;
  className?: string;
}

export default function PainIntensitySlider({ value, onChange, className = "" }: PainIntensitySliderProps) {
  const [isHovering, setIsHovering] = useState(false);

  const getPainLabel = (intensity: number) => {
    if (intensity === 0) return "No Pain";
    if (intensity <= 3) return "Mild";
    if (intensity <= 6) return "Moderate";
    return "Severe";
  };

  const getPainColor = (intensity: number) => {
    if (intensity <= 3) return "text-green-600";
    if (intensity <= 6) return "text-yellow-600";
    return "text-red-600";
  };

  return (
    <div className={className}>
      <Label className="block text-sm font-semibold text-gray-700 mb-3">
        Pain Intensity:{" "}
        <span className={`font-bold ${getPainColor(value)}`}>
          {value}
        </span>
        /10
      </Label>
      <div 
        className="relative mb-4"
        onMouseEnter={() => setIsHovering(true)}
        onMouseLeave={() => setIsHovering(false)}
      >
        <input
          type="range"
          min="0"
          max="10"
          value={value}
          onChange={(e) => onChange(parseInt(e.target.value))}
          className="w-full pain-intensity-slider cursor-pointer"
          style={{
            background: `linear-gradient(to right, 
              hsl(158, 64%, 52%) 0%, 
              hsl(158, 64%, 52%) ${value * 3.33}%, 
              hsl(45, 93%, 47%) ${value * 3.33}%, 
              hsl(45, 93%, 47%) ${value * 6.66}%, 
              hsl(0, 84%, 60%) ${value * 6.66}%, 
              hsl(0, 84%, 60%) 100%)`
          }}
        />
        {isHovering && (
          <div 
            className="absolute -top-10 bg-gray-900 text-white px-2 py-1 rounded text-xs font-medium pointer-events-none"
            style={{ left: `${value * 10}%`, transform: 'translateX(-50%)' }}
          >
            {value}/10
          </div>
        )}
      </div>
      <div className="flex justify-between text-xs text-gray-500">
        <span className="text-green-600 font-medium">No Pain</span>
        <span className="text-yellow-600 font-medium">Mild</span>
        <span className="text-yellow-600 font-medium">Moderate</span>
        <span className="text-red-600 font-medium">Severe</span>
      </div>
      <div className="mt-2 text-center">
        <span className={`text-sm font-semibold ${getPainColor(value)}`}>
          {getPainLabel(value)}
        </span>
      </div>
    </div>
  );
}
