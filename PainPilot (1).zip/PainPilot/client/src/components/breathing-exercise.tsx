import { useState, useEffect, useRef } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";

interface BreathingExerciseProps {
  exerciseType: string;
  title: string;
  onComplete: (duration: number) => void;
  onExit: () => void;
}

const breathingPatterns = {
  "478-breathing": {
    inhale: 4,
    hold1: 7,
    exhale: 8,
    hold2: 0,
    instructions: {
      inhale: "Breathe in through your nose",
      hold1: "Hold your breath",
      exhale: "Exhale slowly through your mouth",
      hold2: "",
    },
  },
  "box-breathing": {
    inhale: 4,
    hold1: 4,
    exhale: 4,
    hold2: 4,
    instructions: {
      inhale: "Breathe in slowly",
      hold1: "Hold your breath",
      exhale: "Breathe out slowly",
      hold2: "Hold empty",
    },
  },
};

export default function BreathingExercise({ exerciseType, title, onComplete, onExit }: BreathingExerciseProps) {
  const [isActive, setIsActive] = useState(false);
  const [phase, setPhase] = useState<"inhale" | "hold1" | "exhale" | "hold2">("inhale");
  const [timeRemaining, setTimeRemaining] = useState(0);
  const [cycleCount, setCycleCount] = useState(0);
  const [sessionDuration, setSessionDuration] = useState(0);
  const [selectedDuration, setSelectedDuration] = useState(5); // minutes
  
  const intervalRef = useRef<NodeJS.Timeout | null>(null);
  const startTimeRef = useRef<number | null>(null);

  const pattern = breathingPatterns[exerciseType as keyof typeof breathingPatterns];

  useEffect(() => {
    if (isActive && timeRemaining > 0) {
      intervalRef.current = setInterval(() => {
        setTimeRemaining(prev => {
          if (prev <= 1) {
            moveToNextPhase();
            return 0;
          }
          return prev - 1;
        });
      }, 1000);
    } else {
      if (intervalRef.current) {
        clearInterval(intervalRef.current);
        intervalRef.current = null;
      }
    }

    return () => {
      if (intervalRef.current) {
        clearInterval(intervalRef.current);
      }
    };
  }, [isActive, timeRemaining]);

  // Session timer
  useEffect(() => {
    if (isActive && startTimeRef.current) {
      const sessionTimer = setInterval(() => {
        const elapsed = Math.floor((Date.now() - startTimeRef.current!) / 1000);
        setSessionDuration(elapsed);

        // Auto-complete after selected duration
        if (elapsed >= selectedDuration * 60) {
          completeSession();
        }
      }, 1000);

      return () => clearInterval(sessionTimer);
    }
  }, [isActive, selectedDuration]);

  const moveToNextPhase = () => {
    const phases: Array<"inhale" | "hold1" | "exhale" | "hold2"> = ["inhale", "hold1", "exhale", "hold2"];
    const currentIndex = phases.indexOf(phase);
    const nextIndex = (currentIndex + 1) % phases.length;
    const nextPhase = phases[nextIndex];

    setPhase(nextPhase);
    
    // Skip hold2 if duration is 0
    if (nextPhase === "hold2" && pattern.hold2 === 0) {
      setPhase("inhale");
      setCycleCount(prev => prev + 1);
      setTimeRemaining(pattern.inhale);
    } else {
      setTimeRemaining(pattern[nextPhase]);
    }

    // Increment cycle count when completing a full cycle
    if (nextPhase === "inhale" && currentIndex === 3) {
      setCycleCount(prev => prev + 1);
    }
  };

  const startExercise = () => {
    setIsActive(true);
    setPhase("inhale");
    setTimeRemaining(pattern.inhale);
    setCycleCount(0);
    setSessionDuration(0);
    startTimeRef.current = Date.now();
  };

  const pauseExercise = () => {
    setIsActive(false);
  };

  const resumeExercise = () => {
    setIsActive(true);
    startTimeRef.current = Date.now() - sessionDuration * 1000;
  };

  const completeSession = () => {
    setIsActive(false);
    const durationMinutes = Math.floor(sessionDuration / 60);
    onComplete(durationMinutes || 1);
  };

  const getPhaseColor = () => {
    switch (phase) {
      case "inhale":
        return "bg-blue-500";
      case "hold1":
        return "bg-purple-500";
      case "exhale":
        return "bg-green-500";
      case "hold2":
        return "bg-yellow-500";
      default:
        return "bg-gray-500";
    }
  };

  const getPhaseInstruction = () => {
    return pattern.instructions[phase] || "";
  };

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-purple-50 to-green-50 flex items-center justify-center p-4">
      <Card className="w-full max-w-md shadow-2xl border-0">
        <CardContent className="p-8 text-center">
          {/* Header */}
          <div className="mb-8">
            <h2 className="text-2xl font-bold text-gray-900 mb-2">{title}</h2>
            <p className="text-gray-600">
              {pattern === breathingPatterns["478-breathing"] 
                ? "Inhale for 4, hold for 7, exhale for 8 seconds"
                : "Equal 4-count breathing pattern"
              }
            </p>
          </div>

          {!isActive && cycleCount === 0 ? (
            /* Setup Screen */
            <div className="space-y-6">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Session Duration
                </label>
                <div className="flex space-x-2 justify-center">
                  {[3, 5, 10, 15].map((duration) => (
                    <Button
                      key={duration}
                      onClick={() => setSelectedDuration(duration)}
                      variant={selectedDuration === duration ? "default" : "outline"}
                      className={selectedDuration === duration ? "gradient-bg text-white" : ""}
                    >
                      {duration}m
                    </Button>
                  ))}
                </div>
              </div>

              <div className="space-y-4">
                <div className="w-32 h-32 mx-auto rounded-full bg-gradient-to-br from-blue-400 to-purple-500 flex items-center justify-center">
                  <svg className="w-16 h-16 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 3v1m0 16v1m9-9h-1M4 12H3m15.364 6.364l-.707-.707M6.343 6.343l-.707-.707m12.728 0l-.707.707M6.343 17.657l-.707.707M16 12a4 4 0 11-8 0 4 4 0 018 0z" />
                  </svg>
                </div>

                <div className="text-sm text-gray-600 space-y-2">
                  <p>• Find a comfortable position</p>
                  <p>• Close your eyes or soften your gaze</p>
                  <p>• Follow the visual and audio cues</p>
                  <p>• Focus on your breath rhythm</p>
                </div>
              </div>

              <div className="space-y-3">
                <Button
                  onClick={startExercise}
                  className="w-full gradient-bg text-white py-3 text-lg font-semibold"
                >
                  Start {selectedDuration}-Minute Session
                </Button>
                <Button
                  onClick={onExit}
                  variant="outline"
                  className="w-full"
                >
                  Back to Modules
                </Button>
              </div>
            </div>
          ) : (
            /* Exercise Screen */
            <div className="space-y-8">
              {/* Progress */}
              <div className="flex justify-between text-sm text-gray-600">
                <span>Cycles: {cycleCount}</span>
                <span>Time: {formatTime(sessionDuration)}</span>
              </div>

              {/* Breathing Circle */}
              <div className="relative">
                <div
                  className={`w-48 h-48 mx-auto rounded-full transition-all duration-1000 ease-in-out flex items-center justify-center ${getPhaseColor()} ${
                    phase === "inhale" ? "scale-110" : phase === "exhale" ? "scale-90" : "scale-100"
                  }`}
                >
                  <div className="text-white text-center">
                    <div className="text-4xl font-bold mb-2">{timeRemaining}</div>
                    <div className="text-lg">{getPhaseInstruction()}</div>
                  </div>
                </div>

                {/* Pulse effect for breathing guidance */}
                <div
                  className={`absolute inset-0 w-48 h-48 mx-auto rounded-full ${getPhaseColor()} opacity-20 animate-ping ${
                    isActive ? "" : "hidden"
                  }`}
                ></div>
              </div>

              {/* Phase indicator */}
              <div className="text-center">
                <div className="text-lg font-semibold text-gray-900 capitalize">
                  {phase === "hold1" ? "Hold" : phase === "hold2" ? "Hold Empty" : phase}
                </div>
                <div className="text-sm text-gray-600 mt-1">
                  {phase === "inhale" && "Fill your lungs slowly and deeply"}
                  {phase === "hold1" && "Keep the air in your lungs"}
                  {phase === "exhale" && "Release the air slowly and completely"}
                  {phase === "hold2" && "Rest with empty lungs"}
                </div>
              </div>

              {/* Controls */}
              <div className="space-y-3">
                {isActive ? (
                  <Button
                    onClick={pauseExercise}
                    variant="outline"
                    className="w-full"
                  >
                    Pause
                  </Button>
                ) : (
                  <Button
                    onClick={resumeExercise}
                    className="w-full gradient-bg text-white"
                  >
                    Resume
                  </Button>
                )}
                
                <div className="flex space-x-3">
                  <Button
                    onClick={completeSession}
                    className="flex-1 bg-green-600 hover:bg-green-700 text-white"
                  >
                    Complete Session
                  </Button>
                  <Button
                    onClick={onExit}
                    variant="outline"
                    className="flex-1"
                  >
                    Exit
                  </Button>
                </div>
              </div>

              {/* Progress bar */}
              <div className="w-full bg-gray-200 rounded-full h-2">
                <div
                  className="bg-gradient-to-r from-blue-500 to-green-500 h-2 rounded-full transition-all duration-300"
                  style={{
                    width: `${Math.min((sessionDuration / (selectedDuration * 60)) * 100, 100)}%`,
                  }}
                ></div>
              </div>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
