import { useState, useEffect, useRef } from "react";
import { useAuth } from "@/hooks/useAuth";
import { useToast } from "@/hooks/use-toast";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";

interface ChatMessage {
  sender: "user" | "bot";
  text: string;
}

const healthFAQ = [
  { q: "headache", a: "For headaches: Stay hydrated, rest in a dark quiet room, apply cold compress. If severe or persistent, consult a doctor." },
  { q: "back pain", a: "For back pain: Try gentle stretching, apply ice/heat, maintain good posture. Rest but avoid prolonged bed rest. See a doctor if pain persists over 2 weeks." },
  { q: "neck pain", a: "For neck pain: Do gentle neck stretches, apply heat, check your posture especially while working. Consider ergonomic adjustments." },
  { q: "joint pain", a: "For joint pain: Rest the affected joint, apply ice, consider gentle movement exercises. Anti-inflammatory foods may help." },
  { q: "muscle pain", a: "For muscle pain: Gentle stretching, warm bath, massage, and rest can help. Stay hydrated and consider magnesium-rich foods." },
  { q: "chronic pain", a: "Managing chronic pain requires a multi-faceted approach: regular gentle exercise, stress management, proper sleep, and working with healthcare professionals." },
  { q: "stress", a: "For stress relief: Practice deep breathing, meditation, regular exercise, and ensure adequate sleep. Consider talking to a mental health professional." },
  { q: "anxiety", a: "For anxiety: Try breathing exercises, progressive muscle relaxation, and grounding techniques. Regular exercise and limiting caffeine can help." },
  { q: "sleep", a: "For better sleep: Maintain a consistent sleep schedule, limit screens before bed, create a dark cool environment, avoid caffeine late in the day." },
  { q: "exercise", a: "Regular exercise helps with pain management. Start slowly, include stretching, and listen to your body. Swimming and walking are gentle options." },
  { q: "medication", a: "Always consult with your healthcare provider before starting, stopping, or changing any medication. Never share or take someone else's medication." },
  { q: "doctor", a: "You should see a doctor if: pain is severe, lasts more than 2 weeks, includes fever, numbness, or affects daily activities significantly." },
  { q: "breathing", a: "Try the 4-7-8 technique: Breathe in for 4 seconds, hold for 7 seconds, exhale for 8 seconds. This can help with relaxation and pain management." },
  { q: "relaxation", a: "Relaxation techniques include: deep breathing, progressive muscle relaxation, guided imagery, meditation, and gentle yoga." },
  { q: "emergency", a: "If experiencing severe chest pain, difficulty breathing, sudden severe headache, or loss of consciousness, call emergency services immediately." },
];

function normalize(text: string): string {
  return text.toLowerCase().replace(/[^a-z0-9\s]/g, "").trim();
}

function getAIResponse(message: string): string {
  const normalizedMessage = normalize(message);
  
  let best: typeof healthFAQ[0] | null = null;
  let bestScore = 0;
  
  for (const faq of healthFAQ) {
    const words = faq.q.split(' ').filter(Boolean);
    let matches = 0;
    for (const word of words) {
      if (normalizedMessage.includes(word)) matches++;
    }
    if (matches > bestScore) {
      bestScore = matches;
      best = faq;
    }
  }
  
  if (best && bestScore > 0) {
    return best.a + "\n\nNote: This is general wellness information. For personalized medical advice, please consult a healthcare professional.";
  }
  
  return "I can help with questions about pain management, breathing exercises, relaxation techniques, and general wellness. For specific medical concerns, please consult a healthcare professional. Try asking about headaches, back pain, stress relief, or breathing techniques!";
}

export default function ChatPage() {
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [input, setInput] = useState("");
  const [loading, setLoading] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const { isAuthenticated, isLoading } = useAuth();
  const { toast } = useToast();

  useEffect(() => {
    if (!isLoading && !isAuthenticated) {
      toast({
        title: "Unauthorized",
        description: "You are logged out. Logging in again...",
        variant: "destructive",
      });
      setTimeout(() => {
        window.location.href = "/api/login";
      }, 500);
      return;
    }
  }, [isAuthenticated, isLoading, toast]);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages]);

  async function sendMessage(e: React.FormEvent) {
    e.preventDefault();
    if (!input.trim()) return;

    const userMessage = input.trim();
    setMessages((prev) => [...prev, { sender: "user", text: userMessage }]);
    setInput("");
    setLoading(true);

    try {
      const res = await fetch("/api/chat", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ message: userMessage }),
        credentials: "include",
      });

      const data = await res.json();
      
      if (data.reply) {
        setMessages((prev) => [...prev, { sender: "bot", text: data.reply }]);
      } else if (data.error) {
        const fallbackResponse = getAIResponse(userMessage);
        setMessages((prev) => [...prev, { sender: "bot", text: fallbackResponse }]);
      }
    } catch (err) {
      console.error(err);
      const fallbackResponse = getAIResponse(userMessage);
      setMessages((prev) => [...prev, { sender: "bot", text: fallbackResponse }]);
    } finally {
      setLoading(false);
    }
  }

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="w-8 h-8 border-4 border-blue-500/30 border-t-blue-500 rounded-full animate-spin"></div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 p-4">
      <div className="max-w-2xl mx-auto">
        <Card className="shadow-lg border-gray-100">
          <CardHeader className="bg-gradient-to-r from-blue-600 to-purple-600 text-white rounded-t-lg">
            <CardTitle className="flex items-center gap-2 text-xl">
              <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 10h.01M12 10h.01M16 10h.01M9 16H5a2 2 0 01-2-2V6a2 2 0 012-2h14a2 2 0 012 2v8a2 2 0 01-2 2h-5l-5 5v-5z" />
              </svg>
              Health AI CHAT BOX
            </CardTitle>
            <p className="text-sm text-white/80">Your AI assistant for pain management and wellness guidance</p>
          </CardHeader>
          <CardContent className="p-0">
            <div className="h-[50vh] overflow-y-auto p-4 space-y-4 bg-gray-50" data-testid="chat-messages">
              {messages.length === 0 && (
                <div className="text-center text-gray-500 py-8">
                  <div className="w-16 h-16 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-4">
                    <svg className="w-8 h-8 text-blue-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 10h.01M12 10h.01M16 10h.01M9 16H5a2 2 0 01-2-2V6a2 2 0 012-2h14a2 2 0 012 2v8a2 2 0 01-2 2h-5l-5 5v-5z" />
                    </svg>
                  </div>
                  <p className="font-medium mb-2">Start a conversation!</p>
                  <p className="text-sm">Ask about pain relief, breathing exercises, or wellness tips.</p>
                </div>
              )}
              {messages.map((m, i) => (
                <div
                  key={i}
                  className={`flex ${m.sender === "user" ? "justify-end" : "justify-start"}`}
                  data-testid={`message-${m.sender}-${i}`}
                >
                  <div
                    className={`max-w-[80%] rounded-2xl px-4 py-3 ${
                      m.sender === "user"
                        ? "bg-blue-600 text-white rounded-br-md"
                        : "bg-white text-gray-800 shadow-sm border border-gray-100 rounded-bl-md"
                    }`}
                  >
                    <p className="text-sm whitespace-pre-wrap">{m.text}</p>
                  </div>
                </div>
              ))}
              {loading && (
                <div className="flex justify-start">
                  <div className="bg-white text-gray-800 shadow-sm border border-gray-100 rounded-2xl rounded-bl-md px-4 py-3">
                    <div className="flex space-x-2">
                      <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce" style={{ animationDelay: "0ms" }}></div>
                      <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce" style={{ animationDelay: "150ms" }}></div>
                      <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce" style={{ animationDelay: "300ms" }}></div>
                    </div>
                  </div>
                </div>
              )}
              <div ref={messagesEndRef} />
            </div>

            <div className="p-4 border-t border-gray-100 bg-white rounded-b-lg">
              <form onSubmit={sendMessage} className="flex gap-2">
                <Input
                  value={input}
                  onChange={(e) => setInput(e.target.value)}
                  className="flex-1"
                  placeholder="Type your health-related question..."
                  disabled={loading}
                  data-testid="input-chat-message"
                />
                <Button 
                  type="submit" 
                  disabled={loading || !input.trim()}
                  className="bg-blue-600 hover:bg-blue-700 text-white"
                  data-testid="button-send-message"
                >
                  <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 19l9 2-9-18-9 18 9-2zm0 0v-8" />
                  </svg>
                </Button>
              </form>
              <p className="text-xs text-gray-500 mt-2 text-center">
                This is for informational purposes only. Always consult a healthcare professional for medical advice.
              </p>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
