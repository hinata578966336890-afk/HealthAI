import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { 
  Activity, 
  Brain, 
  Heart, 
  Shield, 
  Stethoscope, 
  LineChart, 
  MessageSquare, 
  FileText,
  Music,
  BookOpen,
  Code,
  Database,
  Server,
  Palette,
  Lock,
  Users,
  Target,
  Lightbulb,
  CheckCircle2
} from "lucide-react";

export default function About() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-blue-50">
      <div className="max-w-5xl mx-auto px-4 py-8 md:py-12">
        <div className="text-center mb-12">
          <div className="inline-flex items-center gap-2 bg-blue-100 text-blue-700 px-4 py-2 rounded-full text-sm font-medium mb-4">
            <BookOpen className="w-4 h-4" />
            Project Documentation
          </div>
          <h1 className="text-4xl md:text-5xl font-bold text-slate-800 mb-4">
            MediCare AI
          </h1>
          <p className="text-xl text-slate-600 max-w-2xl mx-auto">
            Intelligent Pain Management Application
          </p>
        </div>

        <section className="mb-12 fade-in" data-testid="section-introduction">
          <Card className="card-elevated overflow-hidden">
            <div className="bg-gradient-to-r from-blue-600 to-blue-500 p-6">
              <div className="flex items-center gap-3">
                <div className="w-12 h-12 bg-white/20 rounded-xl flex items-center justify-center">
                  <Lightbulb className="w-6 h-6 text-white" />
                </div>
                <div>
                  <h2 className="text-2xl font-bold text-white">Chapter 1: Introduction</h2>
                  <p className="text-blue-100">About the Subject Area</p>
                </div>
              </div>
            </div>
            <CardContent className="p-6 md:p-8">
              <div className="prose prose-slate max-w-none">
                <h3 className="text-xl font-semibold text-slate-800 mb-4 flex items-center gap-2">
                  <Heart className="w-5 h-5 text-red-500" />
                  Understanding Chronic Pain Management
                </h3>
                <p className="text-slate-600 mb-4 leading-relaxed">
                  Chronic pain affects millions of people worldwide, significantly impacting their quality of life, mental health, and daily functioning. Traditional pain management approaches often rely on medication alone, which may lead to dependency issues and doesn't address the holistic nature of pain experience.
                </p>
                <p className="text-slate-600 mb-4 leading-relaxed">
                  Modern pain management emphasizes a comprehensive approach that combines medical treatment with behavioral strategies, physical therapy, and mental health support. This integrated approach recognizes that pain is not just a physical sensation but a complex experience influenced by psychological, social, and environmental factors.
                </p>
                
                <h3 className="text-xl font-semibold text-slate-800 mb-4 mt-8 flex items-center gap-2">
                  <Target className="w-5 h-5 text-blue-500" />
                  Project Objectives
                </h3>
                <ul className="space-y-3 text-slate-600">
                  <li className="flex items-start gap-3">
                    <CheckCircle2 className="w-5 h-5 text-green-500 mt-0.5 flex-shrink-0" />
                    <span>Provide users with an easy-to-use digital platform for tracking and managing chronic pain</span>
                  </li>
                  <li className="flex items-start gap-3">
                    <CheckCircle2 className="w-5 h-5 text-green-500 mt-0.5 flex-shrink-0" />
                    <span>Leverage artificial intelligence to offer personalized insights and recommendations</span>
                  </li>
                  <li className="flex items-start gap-3">
                    <CheckCircle2 className="w-5 h-5 text-green-500 mt-0.5 flex-shrink-0" />
                    <span>Include therapeutic tools like breathing exercises and sound therapy for natural pain relief</span>
                  </li>
                  <li className="flex items-start gap-3">
                    <CheckCircle2 className="w-5 h-5 text-green-500 mt-0.5 flex-shrink-0" />
                    <span>Generate comprehensive reports to help users communicate with healthcare providers</span>
                  </li>
                  <li className="flex items-start gap-3">
                    <CheckCircle2 className="w-5 h-5 text-green-500 mt-0.5 flex-shrink-0" />
                    <span>Create an accessible, mobile-friendly application that users can access anytime</span>
                  </li>
                </ul>

                <h3 className="text-xl font-semibold text-slate-800 mb-4 mt-8 flex items-center gap-2">
                  <Users className="w-5 h-5 text-purple-500" />
                  Target Users
                </h3>
                <p className="text-slate-600 leading-relaxed">
                  This application is designed for individuals experiencing chronic pain conditions such as fibromyalgia, arthritis, back pain, migraines, and other persistent pain conditions. It also serves healthcare providers who want to monitor patient progress and caregivers supporting individuals with chronic pain.
                </p>
              </div>
            </CardContent>
          </Card>
        </section>

        <section className="mb-12 fade-in" data-testid="section-overview">
          <Card className="card-elevated overflow-hidden">
            <div className="bg-gradient-to-r from-teal-600 to-teal-500 p-6">
              <div className="flex items-center gap-3">
                <div className="w-12 h-12 bg-white/20 rounded-xl flex items-center justify-center">
                  <Stethoscope className="w-6 h-6 text-white" />
                </div>
                <div>
                  <h2 className="text-2xl font-bold text-white">Chapter 2: Overview of Organization</h2>
                  <p className="text-teal-100">Application Structure & Workflow</p>
                </div>
              </div>
            </div>
            <CardContent className="p-6 md:p-8">
              <div className="prose prose-slate max-w-none">
                <h3 className="text-xl font-semibold text-slate-800 mb-4 flex items-center gap-2">
                  <Activity className="w-5 h-5 text-blue-500" />
                  Application Architecture
                </h3>
                <p className="text-slate-600 mb-6 leading-relaxed">
                  MediCare AI is built as a modern web application following a client-server architecture. The frontend provides an intuitive user interface while the backend handles data processing, AI interactions, and secure data storage.
                </p>

                <div className="grid md:grid-cols-2 gap-6 mb-8">
                  <div className="bg-slate-50 rounded-xl p-5 border border-slate-200">
                    <h4 className="font-semibold text-slate-800 mb-3">Frontend (Client)</h4>
                    <ul className="space-y-2 text-slate-600 text-sm">
                      <li>• React-based user interface</li>
                      <li>• Responsive design for all devices</li>
                      <li>• Real-time data visualization</li>
                      <li>• Interactive forms and controls</li>
                    </ul>
                  </div>
                  <div className="bg-slate-50 rounded-xl p-5 border border-slate-200">
                    <h4 className="font-semibold text-slate-800 mb-3">Backend (Server)</h4>
                    <ul className="space-y-2 text-slate-600 text-sm">
                      <li>• Express.js REST API</li>
                      <li>• Secure user authentication</li>
                      <li>• OpenAI GPT-4 integration</li>
                      <li>• Data persistence layer</li>
                    </ul>
                  </div>
                </div>

                <h3 className="text-xl font-semibold text-slate-800 mb-4 flex items-center gap-2">
                  <Shield className="w-5 h-5 text-green-500" />
                  Key Modules
                </h3>
                
                <div className="space-y-4">
                  <div className="flex items-start gap-4 p-4 bg-blue-50 rounded-xl border border-blue-100">
                    <div className="w-10 h-10 bg-blue-500 rounded-lg flex items-center justify-center flex-shrink-0">
                      <Lock className="w-5 h-5 text-white" />
                    </div>
                    <div>
                      <h4 className="font-semibold text-slate-800">Authentication Module</h4>
                      <p className="text-slate-600 text-sm">Secure login system using Replit Auth with OpenID Connect protocol. Manages user sessions and protects personal health data.</p>
                    </div>
                  </div>

                  <div className="flex items-start gap-4 p-4 bg-green-50 rounded-xl border border-green-100">
                    <div className="w-10 h-10 bg-green-500 rounded-lg flex items-center justify-center flex-shrink-0">
                      <Activity className="w-5 h-5 text-white" />
                    </div>
                    <div>
                      <h4 className="font-semibold text-slate-800">Pain Tracking Module</h4>
                      <p className="text-slate-600 text-sm">Comprehensive pain logging with intensity levels (1-10 scale), body location mapping, pain type classification, triggers, and duration tracking.</p>
                    </div>
                  </div>

                  <div className="flex items-start gap-4 p-4 bg-purple-50 rounded-xl border border-purple-100">
                    <div className="w-10 h-10 bg-purple-500 rounded-lg flex items-center justify-center flex-shrink-0">
                      <LineChart className="w-5 h-5 text-white" />
                    </div>
                    <div>
                      <h4 className="font-semibold text-slate-800">Analytics Module</h4>
                      <p className="text-slate-600 text-sm">Visual dashboards showing pain trends over 7, 30, or 90 days. Includes charts, statistics, and pattern recognition for better understanding.</p>
                    </div>
                  </div>

                  <div className="flex items-start gap-4 p-4 bg-amber-50 rounded-xl border border-amber-100">
                    <div className="w-10 h-10 bg-amber-500 rounded-lg flex items-center justify-center flex-shrink-0">
                      <Brain className="w-5 h-5 text-white" />
                    </div>
                    <div>
                      <h4 className="font-semibold text-slate-800">AI Chat Module (Health AI CHAT BOX)</h4>
                      <p className="text-slate-600 text-sm">Intelligent conversational AI powered by OpenAI GPT-4. Provides personalized pain management advice, answers questions, and offers support.</p>
                    </div>
                  </div>

                  <div className="flex items-start gap-4 p-4 bg-teal-50 rounded-xl border border-teal-100">
                    <div className="w-10 h-10 bg-teal-500 rounded-lg flex items-center justify-center flex-shrink-0">
                      <Music className="w-5 h-5 text-white" />
                    </div>
                    <div>
                      <h4 className="font-semibold text-slate-800">Therapeutic Tools Module</h4>
                      <p className="text-slate-600 text-sm">Collection of therapeutic exercises including guided breathing (4-7-8, box breathing), sound therapy (nature sounds, ocean waves), and relaxation exercises.</p>
                    </div>
                  </div>

                  <div className="flex items-start gap-4 p-4 bg-red-50 rounded-xl border border-red-100">
                    <div className="w-10 h-10 bg-red-500 rounded-lg flex items-center justify-center flex-shrink-0">
                      <FileText className="w-5 h-5 text-white" />
                    </div>
                    <div>
                      <h4 className="font-semibold text-slate-800">PDF Report Generation</h4>
                      <p className="text-slate-600 text-sm">Export detailed pain reports as PDF documents. Includes pain history, statistics, and charts for sharing with healthcare providers.</p>
                    </div>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </section>

        <section className="mb-12 fade-in" data-testid="section-technologies">
          <Card className="card-elevated overflow-hidden">
            <div className="bg-gradient-to-r from-purple-600 to-purple-500 p-6">
              <div className="flex items-center gap-3">
                <div className="w-12 h-12 bg-white/20 rounded-xl flex items-center justify-center">
                  <Code className="w-6 h-6 text-white" />
                </div>
                <div>
                  <h2 className="text-2xl font-bold text-white">Technologies Used</h2>
                  <p className="text-purple-100">Technical Stack & Tools</p>
                </div>
              </div>
            </div>
            <CardContent className="p-6 md:p-8">
              <div className="grid md:grid-cols-3 gap-6 mb-8">
                <div className="text-center">
                  <div className="w-16 h-16 bg-blue-100 rounded-2xl flex items-center justify-center mx-auto mb-4">
                    <Palette className="w-8 h-8 text-blue-600" />
                  </div>
                  <h3 className="font-semibold text-slate-800 mb-2">Frontend</h3>
                  <p className="text-slate-600 text-sm">React, TypeScript, Tailwind CSS</p>
                </div>
                <div className="text-center">
                  <div className="w-16 h-16 bg-green-100 rounded-2xl flex items-center justify-center mx-auto mb-4">
                    <Server className="w-8 h-8 text-green-600" />
                  </div>
                  <h3 className="font-semibold text-slate-800 mb-2">Backend</h3>
                  <p className="text-slate-600 text-sm">Node.js, Express, TypeScript</p>
                </div>
                <div className="text-center">
                  <div className="w-16 h-16 bg-purple-100 rounded-2xl flex items-center justify-center mx-auto mb-4">
                    <Brain className="w-8 h-8 text-purple-600" />
                  </div>
                  <h3 className="font-semibold text-slate-800 mb-2">AI Integration</h3>
                  <p className="text-slate-600 text-sm">OpenAI GPT-4 API</p>
                </div>
              </div>

              <Separator className="my-8" />

              <div className="space-y-6">
                <div>
                  <h3 className="text-lg font-semibold text-slate-800 mb-4">Frontend Technologies</h3>
                  <div className="flex flex-wrap gap-2">
                    <Badge variant="secondary" className="bg-blue-100 text-blue-700 hover:bg-blue-200">React 18</Badge>
                    <Badge variant="secondary" className="bg-blue-100 text-blue-700 hover:bg-blue-200">TypeScript</Badge>
                    <Badge variant="secondary" className="bg-blue-100 text-blue-700 hover:bg-blue-200">Tailwind CSS</Badge>
                    <Badge variant="secondary" className="bg-blue-100 text-blue-700 hover:bg-blue-200">Vite</Badge>
                    <Badge variant="secondary" className="bg-blue-100 text-blue-700 hover:bg-blue-200">Wouter</Badge>
                    <Badge variant="secondary" className="bg-blue-100 text-blue-700 hover:bg-blue-200">TanStack Query</Badge>
                    <Badge variant="secondary" className="bg-blue-100 text-blue-700 hover:bg-blue-200">React Hook Form</Badge>
                    <Badge variant="secondary" className="bg-blue-100 text-blue-700 hover:bg-blue-200">Radix UI</Badge>
                    <Badge variant="secondary" className="bg-blue-100 text-blue-700 hover:bg-blue-200">shadcn/ui</Badge>
                    <Badge variant="secondary" className="bg-blue-100 text-blue-700 hover:bg-blue-200">Recharts</Badge>
                    <Badge variant="secondary" className="bg-blue-100 text-blue-700 hover:bg-blue-200">Lucide Icons</Badge>
                    <Badge variant="secondary" className="bg-blue-100 text-blue-700 hover:bg-blue-200">Framer Motion</Badge>
                  </div>
                </div>

                <div>
                  <h3 className="text-lg font-semibold text-slate-800 mb-4">Backend Technologies</h3>
                  <div className="flex flex-wrap gap-2">
                    <Badge variant="secondary" className="bg-green-100 text-green-700 hover:bg-green-200">Node.js</Badge>
                    <Badge variant="secondary" className="bg-green-100 text-green-700 hover:bg-green-200">Express.js</Badge>
                    <Badge variant="secondary" className="bg-green-100 text-green-700 hover:bg-green-200">TypeScript</Badge>
                    <Badge variant="secondary" className="bg-green-100 text-green-700 hover:bg-green-200">Drizzle ORM</Badge>
                    <Badge variant="secondary" className="bg-green-100 text-green-700 hover:bg-green-200">Zod</Badge>
                    <Badge variant="secondary" className="bg-green-100 text-green-700 hover:bg-green-200">Express Sessions</Badge>
                    <Badge variant="secondary" className="bg-green-100 text-green-700 hover:bg-green-200">OpenID Connect</Badge>
                  </div>
                </div>

                <div>
                  <h3 className="text-lg font-semibold text-slate-800 mb-4">AI & External Services</h3>
                  <div className="flex flex-wrap gap-2">
                    <Badge variant="secondary" className="bg-purple-100 text-purple-700 hover:bg-purple-200">OpenAI API</Badge>
                    <Badge variant="secondary" className="bg-purple-100 text-purple-700 hover:bg-purple-200">GPT-4o Model</Badge>
                    <Badge variant="secondary" className="bg-purple-100 text-purple-700 hover:bg-purple-200">Replit Auth</Badge>
                  </div>
                </div>

                <div>
                  <h3 className="text-lg font-semibold text-slate-800 mb-4">Additional Libraries</h3>
                  <div className="flex flex-wrap gap-2">
                    <Badge variant="secondary" className="bg-amber-100 text-amber-700 hover:bg-amber-200">jsPDF</Badge>
                    <Badge variant="secondary" className="bg-amber-100 text-amber-700 hover:bg-amber-200">jspdf-autotable</Badge>
                    <Badge variant="secondary" className="bg-amber-100 text-amber-700 hover:bg-amber-200">html2canvas</Badge>
                    <Badge variant="secondary" className="bg-amber-100 text-amber-700 hover:bg-amber-200">date-fns</Badge>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </section>

        <section className="mb-12 fade-in" data-testid="section-features">
          <Card className="card-elevated overflow-hidden">
            <div className="bg-gradient-to-r from-amber-500 to-orange-500 p-6">
              <div className="flex items-center gap-3">
                <div className="w-12 h-12 bg-white/20 rounded-xl flex items-center justify-center">
                  <MessageSquare className="w-6 h-6 text-white" />
                </div>
                <div>
                  <h2 className="text-2xl font-bold text-white">Feature Explanations</h2>
                  <p className="text-amber-100">Detailed Feature Walkthrough</p>
                </div>
              </div>
            </div>
            <CardContent className="p-6 md:p-8">
              <div className="space-y-8">
                <div className="border-b border-slate-200 pb-6">
                  <h3 className="text-xl font-semibold text-slate-800 mb-3 flex items-center gap-2">
                    <span className="w-8 h-8 bg-blue-500 text-white rounded-lg flex items-center justify-center text-sm font-bold">1</span>
                    Login Page & Authentication
                  </h3>
                  <p className="text-slate-600 leading-relaxed mb-4">
                    The application uses Replit Auth for secure user authentication. Users can log in with their Replit account, which provides OAuth 2.0 security without storing passwords locally. Once authenticated, users get a personalized experience with their data securely stored and accessible only to them.
                  </p>
                  <div className="bg-slate-50 rounded-lg p-4">
                    <p className="text-sm text-slate-500">
                      <strong>Technical:</strong> OpenID Connect protocol with session management. User data is stored securely and sessions expire for security.
                    </p>
                  </div>
                </div>

                <div className="border-b border-slate-200 pb-6">
                  <h3 className="text-xl font-semibold text-slate-800 mb-3 flex items-center gap-2">
                    <span className="w-8 h-8 bg-green-500 text-white rounded-lg flex items-center justify-center text-sm font-bold">2</span>
                    Pain Entry & Logging
                  </h3>
                  <p className="text-slate-600 leading-relaxed mb-4">
                    Users can log their pain experiences with comprehensive details including:
                  </p>
                  <ul className="list-disc list-inside text-slate-600 space-y-2 ml-4">
                    <li><strong>Pain Intensity:</strong> Visual slider scale from 1 (mild) to 10 (severe)</li>
                    <li><strong>Body Location:</strong> Select the specific area where pain is felt</li>
                    <li><strong>Pain Type:</strong> Categorize as sharp, dull, throbbing, burning, or aching</li>
                    <li><strong>Duration:</strong> Track how long the pain episode lasts</li>
                    <li><strong>Triggers:</strong> Identify activities or situations that caused the pain</li>
                    <li><strong>Notes:</strong> Add additional context or observations</li>
                  </ul>
                </div>

                <div className="border-b border-slate-200 pb-6">
                  <h3 className="text-xl font-semibold text-slate-800 mb-3 flex items-center gap-2">
                    <span className="w-8 h-8 bg-purple-500 text-white rounded-lg flex items-center justify-center text-sm font-bold">3</span>
                    Pain Analytics Dashboard
                  </h3>
                  <p className="text-slate-600 leading-relaxed mb-4">
                    The analytics page provides visual insights into pain patterns:
                  </p>
                  <ul className="list-disc list-inside text-slate-600 space-y-2 ml-4">
                    <li><strong>Time Period Filters:</strong> View data for last 7, 30, or 90 days</li>
                    <li><strong>Pain Trend Charts:</strong> Line graphs showing pain intensity over time</li>
                    <li><strong>Average Pain Level:</strong> Statistical summary of pain intensity</li>
                    <li><strong>Pain-Free Days:</strong> Track days without significant pain</li>
                    <li><strong>Location Analysis:</strong> See which body areas are most affected</li>
                    <li><strong>Pattern Recognition:</strong> Identify recurring pain patterns</li>
                  </ul>
                </div>

                <div className="border-b border-slate-200 pb-6">
                  <h3 className="text-xl font-semibold text-slate-800 mb-3 flex items-center gap-2">
                    <span className="w-8 h-8 bg-amber-500 text-white rounded-lg flex items-center justify-center text-sm font-bold">4</span>
                    Health AI CHAT BOX
                  </h3>
                  <p className="text-slate-600 leading-relaxed mb-4">
                    An intelligent AI assistant powered by OpenAI's GPT-4 model that:
                  </p>
                  <ul className="list-disc list-inside text-slate-600 space-y-2 ml-4">
                    <li>Answers questions about pain management techniques</li>
                    <li>Provides personalized suggestions based on user's pain history</li>
                    <li>Offers emotional support and encouragement</li>
                    <li>Explains medical concepts in simple terms</li>
                    <li>Suggests when to seek professional medical help</li>
                  </ul>
                  <div className="bg-amber-50 rounded-lg p-4 mt-4">
                    <p className="text-sm text-amber-800">
                      <strong>Note:</strong> The AI provides general information only and does not replace professional medical advice.
                    </p>
                  </div>
                </div>

                <div className="border-b border-slate-200 pb-6">
                  <h3 className="text-xl font-semibold text-slate-800 mb-3 flex items-center gap-2">
                    <span className="w-8 h-8 bg-teal-500 text-white rounded-lg flex items-center justify-center text-sm font-bold">5</span>
                    Therapeutic Tools
                  </h3>
                  <p className="text-slate-600 leading-relaxed mb-4">
                    A collection of evidence-based therapeutic exercises:
                  </p>
                  <div className="grid md:grid-cols-2 gap-4 mt-4">
                    <div className="bg-teal-50 rounded-lg p-4">
                      <h4 className="font-semibold text-teal-800 mb-2">Breathing Exercises</h4>
                      <ul className="text-sm text-teal-700 space-y-1">
                        <li>• 4-7-8 Relaxation Breathing</li>
                        <li>• Box Breathing Technique</li>
                        <li>• Deep Diaphragmatic Breathing</li>
                      </ul>
                    </div>
                    <div className="bg-blue-50 rounded-lg p-4">
                      <h4 className="font-semibold text-blue-800 mb-2">Sound Therapy</h4>
                      <ul className="text-sm text-blue-700 space-y-1">
                        <li>• Nature Sounds</li>
                        <li>• Ocean Waves</li>
                        <li>• Tibetan Singing Bowls</li>
                      </ul>
                    </div>
                  </div>
                </div>

                <div>
                  <h3 className="text-xl font-semibold text-slate-800 mb-3 flex items-center gap-2">
                    <span className="w-8 h-8 bg-red-500 text-white rounded-lg flex items-center justify-center text-sm font-bold">6</span>
                    PDF Report Generation
                  </h3>
                  <p className="text-slate-600 leading-relaxed mb-4">
                    Generate comprehensive PDF reports that include:
                  </p>
                  <ul className="list-disc list-inside text-slate-600 space-y-2 ml-4">
                    <li>Complete pain history for the selected time period</li>
                    <li>Statistical summary with averages and trends</li>
                    <li>Visual charts and graphs</li>
                    <li>List of all pain entries with details</li>
                    <li>Professional formatting suitable for medical appointments</li>
                  </ul>
                  <div className="bg-slate-50 rounded-lg p-4 mt-4">
                    <p className="text-sm text-slate-500">
                      <strong>Use Case:</strong> Share these reports with your doctor to help them understand your pain patterns and make informed treatment decisions.
                    </p>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </section>

        <footer className="text-center py-8">
          <div className="text-slate-500 text-sm">
            <p className="mb-2">MediCare AI - Intelligent Pain Management Application</p>
            <p>Built with modern web technologies for better health outcomes</p>
          </div>
        </footer>
      </div>
    </div>
  );
}
